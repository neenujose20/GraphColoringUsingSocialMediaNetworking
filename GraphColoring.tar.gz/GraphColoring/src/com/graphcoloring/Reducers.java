package com.graphcoloring;

// <editor-fold defaultstate="collapsed" desc="packages">
import com.bean.Message;
import com.bean.Vertex;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

// </editor-fold>

public class Reducers {

    public static class PreProcess extends Reducer<IntWritable, IntWritable, IntWritable, Text> {

        Text value = new Text();

        @Override
        protected void reduce(IntWritable key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException {
            StringBuilder sb = new StringBuilder();
            for (IntWritable v : values) {
                if (sb.length() != 0) {
                    sb.append(",");
                }
                sb.append(v.get());
            }
            value.set(sb.toString());
            context.write(key, value);
        }

    }

    public static class Stage1 extends Reducer<Vertex, Message, Text, Vertex> {

        @Override
        protected void reduce(Vertex key, Iterable<Message> values, Context context) throws IOException, InterruptedException {
            System.out.println("key = " + key.toString());
            for (Message value : values) {
                System.out.println("value = " + value.toString());
            }
            System.out.println("");
        }

    }
    
    
    
    public static class SuperStep0 extends Reducer<Vertex, IntWritable, IntWritable, Message> 
    {

        @Override
        protected void reduce(Vertex key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException 
        {
            Iterator<IntWritable> iterator = values.iterator();
            
            List<IntWritable> vIds=new ArrayList<>();
            int degree=0;
            Message message;
            
            StringBuilder edgesTo=new StringBuilder();
            while (iterator.hasNext()) 
            {
                IntWritable vID = iterator.next();
                edgesTo.append(vID).append(",");
                ++degree;
                vIds.add(new IntWritable(vID.get()));
            }
            
            String edgesToStr=edgesTo.substring(0, edgesTo.length()-1);
            
            key.setEdgesTo(edgesToStr);
            key.setValue(-1);
            
            key.setDegree(degree);
            try {
                Config.vertices.put(key.getVertexId(), (Vertex) key.clone());
            } catch (CloneNotSupportedException ex) {
                Logger.getLogger(Reducers.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            
            
            for (IntWritable vId : vIds) 
            {
                message=new Message();
                message.setvDegree(degree);
                message.setvID(key.getVertexId());
                
//                if(vId.get()==1)
//                    System.out.println("vId = " + vId);
                context.write(vId, message);
                
            }
             
           
        }

        

    }
    
    
    public static class SuperStep extends Reducer<Vertex, Message, IntWritable, Message> 
    {

        Message message;
        @Override
        protected void reduce(Vertex key, Iterable<Message> messages, Context context) throws IOException, InterruptedException {
//            if(key.getVertexId()==1)
//            {
//                System.out.println("*********************************");
//                System.out.println("*********************************");
//                messages.forEach(message -> {
//                    System.out.println(message);
//                });
//            }
            
            System.out.println("***********************        "+key.getVertexId()+"        ********************************");
            boolean MaxVal=true;
            boolean MinVal=true;
            
            
            if(key.getValue()==-1)
            {
                
                
                Iterator<Message> iterator = messages.iterator();
                while (iterator.hasNext()) 
                {
                    Message message = iterator.next();
                    System.out.println(message);
                    
                    int vertexId=message.getvID();
                    int degree=message.getvDegree();
                    if(key.getDegree() < degree)
                    {
                        MaxVal=false;
                    }
                    else if(key.getDegree() > degree)
                    {
                        MinVal=false;
                    }
                    else
                    {
                        if(vertexId > key.getVertexId())
                        {
                            MaxVal=false;
                        }
                        else
                        {
                            MinVal=false;
                        }
                    }
                }
                
                if(MaxVal)
                {
                    int value=2 * Config.SUPER_STEP_NO;
                    key.setValue(value);
                    Config.vertices.get(key.getVertexId()).setValue(value);
//                    System.out.println("update un max "+key.getVertexId());
                }
                else if(MinVal)
                {
                    int value=2 * Config.SUPER_STEP_NO - 1 ;
                    key.setValue(value);
                    Config.vertices.get(key.getVertexId()).setValue(value);
//                    System.out.println("update un min "+key.getVertexId());
                }
                else
                {
                    for (String neighbour : key.getEdgesTo().split(",")) 
                    {
                        int neighbourId=Integer.parseInt(neighbour);
                        message=new Message();
                        message.setvDegree(key.getDegree());
                        message.setvID(key.getVertexId());
                        
                        context.write(new IntWritable(neighbourId), message);
                    }
                }
            }
            
//            for (Integer integer : Config.vertexes.keySet()) {
//                System.out.println("integer = " + Config.vertexes.get(integer));
//            }

            System.out.println("****************************************");
        }
        
        
    }

}
