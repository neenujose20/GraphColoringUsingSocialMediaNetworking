package com.graphcoloring;

// <editor-fold defaultstate="collapsed" desc="packages">
import com.bean.Message;
import com.bean.Vertex;
import java.io.IOException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

// </editor-fold>

public class Mappers {

    public static class PreProcess extends Mapper<LongWritable, Text, IntWritable, IntWritable> {

        IntWritable k = new IntWritable();
        IntWritable v = new IntWritable();

        @Override
        protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
            String[] sp = value.toString().split("\\s+");
            k.set(Integer.parseInt(sp[0]));
            v.set(Integer.parseInt(sp[1]));
            context.write(k, v);
            
            if(k.get()==1)
                System.out.println("jyeeygy");
//            context.write(v, k);
        }

    }

    public static class Stage1 extends Mapper<LongWritable, Text, Vertex, Message> {

        Vertex vertex = new Vertex();
        Message msg = new Message();

        @Override
        protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
//            String[] sp = value.toString().split("\\s+");
//            msg.setMsg(Integer.parseInt(sp[0]) + sp[1].split(",").length);
//            vertex.setValue(-1);
//            for (String string : sp[1].split(",")) {
//                string = string.trim();
//                vertex.setVertexId(Integer.parseInt(string));
//                context.write(vertex, msg);
//            }
//            
        }

    }
    
    
    public static class SuperStep0 extends Mapper<LongWritable, Text, Vertex, IntWritable> {

        Vertex vertex = new Vertex();
        IntWritable vNeighbour = new IntWritable();

        @Override
        protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException 
        {
            Vertex vertex = new Vertex();
            String[] sp = value.toString().split("\\s+");
            vertex.setVertexId(Integer.parseInt(sp[0]));
            vNeighbour.set(Integer.parseInt(sp[1]));

            
            context.write(vertex, vNeighbour);
        }

    }

    
    public static class SuperStep extends Mapper<IntWritable, Message, Vertex, Message> {

        Set<Integer> vertexIds=new HashSet<>();
        @Override
        protected void map(IntWritable key, Message message, Context context) throws IOException, InterruptedException {
            
            Vertex vertex=Config.vertices.get(key.get());
           
            context.write(vertex, message);
            vertexIds.add(key.get());
//            System.out.println("vertex = " + vertex);
            
        }

        /**
         * there are situation in which vertex won't receive any message at all
         * for that we create null message for that vertex
         * @param context
         * @throws IOException
         * @throws InterruptedException 
         */
        @Override
        protected void cleanup(Context context) throws IOException, InterruptedException 
        {
            List<Integer> noMessageVertices = Config.vertices.keySet().stream().filter( key -> !vertexIds.contains(key)).collect(Collectors.toList());
            
            for (Integer noMessageVertexe : noMessageVertices) 
            {
                Vertex vertex=Config.vertices.get(noMessageVertexe);
                
                context.write(vertex, new Message());
            }
        }

        
        
    }

}
