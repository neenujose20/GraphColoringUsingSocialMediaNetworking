/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.graphcoloring;

import com.bean.Vertex;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Stream;


public class Config 
{
    public volatile static Map<Integer,Vertex> vertices;
    public static final String SUPER_STEP="Steps"+File.separator+"SUPER_STEP";
    public volatile static  int SUPER_STEP_NO=0;
    
    static {
        vertices=new HashMap<>();
    }
    
    public static  void deleteFolder(String dir) {
        File folder=new File(dir);
        if(folder.exists())
        {
            try(Stream<java.nio.file.Path> filePaths=Files.list(Paths.get(dir)))
                {
                    filePaths.forEach(filePath -> {
                        File file=filePath.toFile();
                        if(file.isDirectory())
                            deleteFolder(file.getAbsolutePath());
                        else
                            file.delete();
                    });
                } catch (IOException ex) {
                Logger.getLogger(Config.class.getName()).log(Level.SEVERE, null, ex);
            }
          new File(dir).delete();
        }
        else
        {
            System.out.println("folder = ");
        }
    }
}
