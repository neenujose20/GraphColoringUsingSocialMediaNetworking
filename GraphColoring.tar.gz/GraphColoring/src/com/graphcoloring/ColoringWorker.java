/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.graphcoloring;

import com.bean.Vertex;
import com.graphcoloring.util.AllColoredPredicate;
import java.io.File;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.SwingWorker;


public class ColoringWorker extends SwingWorker<Boolean, String>
{

    private String inPath;
    private JButton coloringBTN;
    private JLabel labColors;private JLabel labSteps;
    private JLabel labVert;
    private JTextArea console;
    public ColoringWorker(String inPath) {
        this.inPath = inPath;
    }
    
    
    @Override
    protected Boolean doInBackground() throws Exception 
    {
        init();
        
        GraphColoring graphColoring=new GraphColoring();
        boolean superStep = graphColoring.superStep0(getInPath());
        
        // if init fails return to caller
        if(!superStep)
            return false;
        
        int noOfVertices = Config.vertices.size();
        labVert.setText(noOfVertices+"");
        
        System.out.println("super out= " + Config.SUPER_STEP_NO);
        
        boolean unColored,stepResult;
            
        do
        {
            super.publish("Super Step "+Config.SUPER_STEP_NO);
            stepResult = graphColoring.superStetp();
            
            // finds whether any uncolored vertex exist in the graph
            unColored = Config.vertices.keySet().stream().anyMatch(AllColoredPredicate.isColored());
            
        }while(unColored && stepResult);
        
        return true;
    }
    
    @Override
    protected void process(List<String> chunks) {
        String updateMessage=chunks.get(chunks.size()-1);
        coloringBTN.setText(updateMessage);
    }

    @Override
    protected void done() {
        try {
            boolean status=get();
            
            if(status)
            {
                long noOfColors = Config.vertices.values().stream().map(vertex -> vertex.getValue()).distinct().count();
                labColors.setText(noOfColors+"");
                labSteps.setText((Config.SUPER_STEP_NO-1)+"");
                
                for (Map.Entry<Integer, Vertex> entry : Config.vertices.entrySet()) {
                    Integer key = entry.getKey();
                    Vertex vertex = entry.getValue();
                     console.append(vertex.toString());
                     console.append("\n");
                }
                
//                Config.vertices.values().stream().map(vertex -> vertex.getValue()).distinct().sorted().forEach(System.out::println);
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Something went wrong", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (InterruptedException | ExecutionException ex) {
            Logger.getLogger(ColoringWorker.class.getName()).log(Level.SEVERE, null, ex);
        }
        finally{
            coloringBTN.setActionCommand("start");
            coloringBTN.setText("Start Coloring");
            coloringBTN.setIcon(null);
        }
    }

    
    
    
    /**
     * @return the inPath
     */
    public String getInPath() {
        return inPath;
    }

    /**
     * @param inPath the inPath to set
     */
    public void setInPath(String inPath) {
        this.inPath = inPath;
    }

    /**
     * @return the coloringBTN
     */
    public JButton getColoringBTN() {
        return coloringBTN;
    }

    /**
     * @param coloringBTN the coloringBTN to set
     */
    public void setColoringBTN(JButton coloringBTN) {
        this.coloringBTN = coloringBTN;
    }

    /**
     * @return the labColors
     */
    public JLabel getLabColors() {
        return labColors;
    }

    /**
     * @param labColors the labColors to set
     */
    public void setLabColors(JLabel labColors) {
        this.labColors = labColors;
    }

    /**
     * @return the labSteps
     */
    public JLabel getLabSteps() {
        return labSteps;
    }

    /**
     * @param labSteps the labSteps to set
     */
    public void setLabSteps(JLabel labSteps) {
        this.labSteps = labSteps;
    }

    /**
     * @return the labVert
     */
    public JLabel getLabVert() {
        return labVert;
    }

    /**
     * @param labVert the labVert to set
     */
    public void setLabVert(JLabel labVert) {
        this.labVert = labVert;
    }

    /**
     * @return the console
     */
    public JTextArea getConsole() {
        return console;
    }

    /**
     * @param console the console to set
     */
    public void setConsole(JTextArea console) {
        this.console = console;
    }

    private void init() 
    {
        Config.deleteFolder(Config.SUPER_STEP.split(File.separator)[0]+File.separator);
        console.setText("");
        labColors.setText("");
        labSteps.setText("");
        labVert.setText("");
        
        coloringBTN.setActionCommand("coloring");
        
        coloringBTN.setIcon( new ImageIcon(getClass().getResource("/com/gui/wait.png")));
        coloringBTN.setText("Initializing");
        Config.SUPER_STEP_NO=0;
        Config.vertices.clear();
    }
    
    
    
}
