package com.graphcoloring;

import com.bean.Message;
import com.bean.Vertex;
import com.graphcoloring.mapred.GraphColorMaperInit;
import com.graphcoloring.mapred.GraphColorMaperSuperStep;
import com.graphcoloring.mapred.SmallestLargestDegreeInitReducer;
import com.graphcoloring.mapred.SmallestLargestDegreeSuperStepReducer;
import com.graphcoloring.util.AllColoredPredicate;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.SequenceFileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.SequenceFileOutputFormat;


public class GraphColoring {

    public GraphColoring() {
    }

    
    public static void main(String[] args) {
//       
        GraphColoring obj=new GraphColoring();
        try 
        {
            obj.superStep0();
            boolean unColored;
            
            do
            {
                obj.superStetp();
                unColored = Config.vertices.keySet().stream().anyMatch(AllColoredPredicate.isColored());
            
            }while(unColored);
            
        } catch (IOException | InterruptedException | ClassNotFoundException ex) {
            Logger.getLogger(GraphColoring.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    
    
    
    
    public void superStep0() throws IOException, InterruptedException, ClassNotFoundException
    {
        String inPath="Data/sample";
        String outPath=Config.SUPER_STEP+Config.SUPER_STEP_NO;
        Config.deleteFolder(outPath);
        Job job = new Job();
        job.setJarByClass(GraphColoring.class);
        job.setJobName("SuperStep"+Config.SUPER_STEP_NO);
         
        FileInputFormat.addInputPath(job, new Path(inPath));
        FileOutputFormat.setOutputPath(job, new Path(outPath));
        
        job.setOutputKeyClass(IntWritable.class);
        job.setOutputValueClass(Message.class);
        
        job.setMapOutputKeyClass(Vertex.class);
        job.setMapOutputValueClass(IntWritable.class);
//         job.setNumReduceTasks(1);
        job.setOutputFormatClass(SequenceFileOutputFormat.class);
        job.setInputFormatClass(TextInputFormat.class);
        
        job.setMapperClass(Mappers.SuperStep0.class);
        job.setReducerClass(Reducers.SuperStep0.class);
        job.waitForCompletion(true);
        ++Config.SUPER_STEP_NO;
    }
    
    public boolean superStep0(String inPath) throws IOException, InterruptedException, ClassNotFoundException
    {
        String outPath=Config.SUPER_STEP+Config.SUPER_STEP_NO;
        Config.deleteFolder(outPath);
        Job job = new Job();
        job.setJarByClass(GraphColoring.class);
        job.setJobName("SuperStep"+Config.SUPER_STEP_NO);
         
        FileInputFormat.addInputPath(job, new Path(inPath));
        FileOutputFormat.setOutputPath(job, new Path(outPath));
        
        job.setOutputKeyClass(IntWritable.class);
        job.setOutputValueClass(Message.class);
        
        job.setMapOutputKeyClass(Vertex.class);
        job.setMapOutputValueClass(IntWritable.class);
//         job.setNumReduceTasks(1);
        job.setOutputFormatClass(SequenceFileOutputFormat.class);
        job.setInputFormatClass(TextInputFormat.class);
        
        job.setMapperClass(GraphColorMaperInit.class);
        job.setReducerClass(SmallestLargestDegreeInitReducer.class);
        job.waitForCompletion(true);
        
        ++Config.SUPER_STEP_NO;
        return job.isSuccessful();
    }
    
    
    public boolean superStetp() throws IOException, InterruptedException, ClassNotFoundException
    {
        
        
        String inPath=Config.SUPER_STEP+(Config.SUPER_STEP_NO -1);
        
        
        String outPath=Config.SUPER_STEP+Config.SUPER_STEP_NO;
        Config.deleteFolder(outPath);
        Job job = new Job();
        job.setJarByClass(GraphColoring.class);
        job.setJobName("SuperStep"+Config.SUPER_STEP_NO);
         
        FileInputFormat.addInputPath(job, new Path(inPath));
        FileOutputFormat.setOutputPath(job, new Path(outPath));
        
        job.setOutputKeyClass(IntWritable.class);
        job.setOutputValueClass(Message.class);
        
        job.setMapOutputKeyClass(Vertex.class);
        job.setMapOutputValueClass(Message.class);
        
//        job.setNumReduceTasks(1);
        job.setOutputFormatClass(SequenceFileOutputFormat.class);
        job.setInputFormatClass(SequenceFileInputFormat.class);
        
        job.setMapperClass(GraphColorMaperSuperStep.class);
        job.setReducerClass(SmallestLargestDegreeSuperStepReducer.class);
        job.waitForCompletion(true);
        
//        if(job.isSuccessful())
//        {
//            for (Map.Entry<Integer, Vertex> entry : Config.vertices.entrySet()) {
//               Integer key = entry.getKey();
//               Vertex vertex = entry.getValue();
//                System.out.println(vertex);
//            }
//        }

        ++Config.SUPER_STEP_NO;
        return job.isSuccessful();
    }

}
