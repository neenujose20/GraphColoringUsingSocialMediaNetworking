/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.graphcoloring.mapred;

import com.bean.Vertex;
import java.io.IOException;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;


public class GraphColorMaperInit extends Mapper<LongWritable, Text, Vertex, IntWritable> 
{
    IntWritable vNeighbour = new IntWritable();

    @Override
    protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException 
    {
//        Vertex vertex = new Vertex();
//        String[] sp = value.toString().split("\\s+");
//        vertex.setVertexId(Integer.parseInt(sp[0]));
//        vNeighbour.set(Integer.parseInt(sp[1]));
//
//
//        context.write(vertex, vNeighbour);
        
        String[] sp = value.toString().split("\\s+");
        int v1=Integer.parseInt(sp[0]);
        int v2=Integer.parseInt(sp[1]);
        Vertex vertex = new Vertex();
        vertex.setVertexId(v1);
        vNeighbour.set(v2);


        context.write(vertex, vNeighbour);
        
        
        vertex=new Vertex();
        vertex.setVertexId(v2);
        vNeighbour.set(v1);
        context.write(vertex, vNeighbour);
    }
}
