/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.graphcoloring.mapred;

import com.bean.Message;
import com.bean.Vertex;
import com.graphcoloring.Config;
import java.io.IOException;
import java.util.Iterator;
import org.apache.hadoop.io.IntWritable;


public class SmallestLargestDegreeSuperStepReducer extends GraphColorReducerSuperStep{

    Message message;
    @Override
    protected void reduce(Vertex key, Iterable<Message> messages, Context context) throws IOException, InterruptedException 
    {
        System.out.println("***********************        "+key.getVertexId()+"        ********************************");
        boolean MaxVal=true;
        boolean MinVal=true;


        if(key.getValue()==-1)
        {


            Iterator<Message> iterator = messages.iterator();
            while (iterator.hasNext()) 
            {
                Message message = iterator.next();
                System.out.println(message);

                int vertexId=message.getvID();
                int degree=message.getvDegree();
                if(key.getDegree() < degree)
                {
                    MaxVal=false;
                }
                else if(key.getDegree() > degree)
                {
                    MinVal=false;
                }
                else
                {
                    if(vertexId > key.getVertexId())
                    {
                        MaxVal=false;
                    }
                    else
                    {
                        MinVal=false;
                    }
                }
            }

            if(MaxVal)
            {
                int value=2 * Config.SUPER_STEP_NO;
                key.setValue(value);
                Config.vertices.get(key.getVertexId()).setValue(value);
            }
            else if(MinVal)
            {
                int value=2 * Config.SUPER_STEP_NO - 1 ;
                key.setValue(value);
                Config.vertices.get(key.getVertexId()).setValue(value);
            }
            else
            {
                for (String neighbour : key.getEdgesTo().split(",")) 
                {
                    int neighbourId=Integer.parseInt(neighbour);
                    message=new Message();
                    message.setvDegree(key.getDegree());
                    message.setvID(key.getVertexId());

                    context.write(new IntWritable(neighbourId), message);
                }
            }
        }
        System.out.println("****************************************");
    }
        
}


