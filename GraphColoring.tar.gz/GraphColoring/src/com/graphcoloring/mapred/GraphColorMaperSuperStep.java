/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.graphcoloring.mapred;

import com.bean.Message;
import com.bean.Vertex;
import com.graphcoloring.Config;
import java.io.IOException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.mapreduce.Mapper;


public class GraphColorMaperSuperStep extends Mapper<IntWritable, Message, Vertex, Message> {

    Set<Integer> vertexIds=new HashSet<>();
    @Override
    protected void map(IntWritable key, Message message, Mapper.Context context) throws IOException, InterruptedException {

        Vertex vertex=Config.vertices.get(key.get());

        context.write(vertex, message);
        vertexIds.add(key.get());
//            System.out.println("vertex = " + vertex);

    }

    /**
     * there are situation in which vertex won't receive any message at all
     * for that we create null message for that vertex
     * @param context
     * @throws IOException
     * @throws InterruptedException 
     */
    @Override
    protected void cleanup(Mapper.Context context) throws IOException, InterruptedException 
    {
        List<Integer> noMessageVertices = Config.vertices.keySet().stream().filter( key -> !vertexIds.contains(key)).collect(Collectors.toList());

        for (Integer noMessageVertexe : noMessageVertices) 
        {
            Vertex vertex=Config.vertices.get(noMessageVertexe);

            context.write(vertex, new Message());
        }
    }

}
