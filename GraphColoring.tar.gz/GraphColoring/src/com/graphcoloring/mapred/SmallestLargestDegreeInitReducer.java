/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.graphcoloring.mapred;

import com.bean.Message;
import com.bean.Vertex;
import com.graphcoloring.Config;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.hadoop.io.IntWritable;


public class SmallestLargestDegreeInitReducer extends GraphColorReducerInit
{
    @Override
    protected void reduce(Vertex key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException
    {
        Iterator<IntWritable> iterator = values.iterator();
            
        List<IntWritable> vIds=new ArrayList<>();
        int degree=0;
        Message message;

        StringBuilder edgesTo=new StringBuilder();
        while (iterator.hasNext()) 
        {
            IntWritable vID = iterator.next();
            edgesTo.append(vID).append(",");
            ++degree;
            vIds.add(new IntWritable(vID.get()));
        }

        String edgesToStr=edgesTo.substring(0, edgesTo.length()-1);

        key.setEdgesTo(edgesToStr);
        key.setValue(-1);

        key.setDegree(degree);
        
        try {
            Config.vertices.put(key.getVertexId(), (Vertex) key.clone());
        } catch (CloneNotSupportedException ex) {
            Logger.getLogger(SmallestLargestDegreeInitReducer.class.getName()).log(Level.SEVERE, null, ex);
        }
        



        for (IntWritable vId : vIds) 
        {
            message=new Message();
            message.setvDegree(degree);
            message.setvID(key.getVertexId());
            context.write(vId, message);

        }


    }
   

}
