package com.bean;

// <editor-fold defaultstate="collapsed" desc="packages">
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableUtils;

// </editor-fold>

public class Vertex implements WritableComparable<Vertex> {

    private int vertexId;
    private int value;
    private int degree;
    private String edgesTo;

    public Integer getVertexId() {
        return vertexId;
    }

    public void setVertexId(Integer vertexId) {
        this.vertexId = vertexId;
    }

    public Integer getValue() {
        return value;
    }

    public void setValue(Integer value) {
        this.value = value;
    }

    public String getEdgesTo() {
        return edgesTo;
    }

    public void setEdgesTo(String edgesTo) {
        this.edgesTo = edgesTo;
    }

    @Override
    public void write(DataOutput d) throws IOException {
        WritableUtils.writeVInt(d, vertexId);
        WritableUtils.writeVInt(d, value);
        WritableUtils.writeString(d, edgesTo);
        WritableUtils.writeVInt(d, getDegree());
    }

    @Override
    public void readFields(DataInput di) throws IOException {
        vertexId = WritableUtils.readVInt(di);
        value = WritableUtils.readVInt(di);
        edgesTo = WritableUtils.readString(di);
        setDegree(WritableUtils.readVInt(di));
    }

    @Override
    public int compareTo(Vertex o) {
        int res =Integer.compare(vertexId, o.vertexId);
//        int res = vertexId.compareTo(o.vertexId);
        return res;
    }

    @Override
    public String toString() {
        return "Vertex{" + "vertexId=" + vertexId + ", value=" + value + ", degree=" + degree + '}';
    }

    

    /**
     * @return the degree
     */
    public int getDegree() {
        return degree;
    }

    /**
     * @param degree the degree to set
     */
    public void setDegree(int degree) {
        this.degree = degree;
    }

    

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Vertex other = (Vertex) obj;
        if (this.vertexId != other.vertexId) {
            return false;
        }
        return true;
    }

    @Override
    public Object clone() throws CloneNotSupportedException
    {
        Vertex vertex=new Vertex();
        vertex.setDegree(this.degree);
        vertex.setEdgesTo(this.edgesTo+"");
        vertex.setValue(this.value);
        vertex.setVertexId(this.vertexId);
        
        return vertex;
    }

     

    
    
    
}
