package com.bean;

// <editor-fold defaultstate="collapsed" desc="packages">

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableUtils;



// </editor-fold>

public class Message implements WritableComparable<Message>{
    
    private int vID;
    private int vDegree;

    @Override
    public void write(DataOutput d) throws IOException {
        WritableUtils.writeVInt(d, getvID());
        WritableUtils.writeVInt(d, getvDegree());
    }

    @Override
    public void readFields(DataInput di) throws IOException {
        setvID((Integer) WritableUtils.readVInt(di));
        setvDegree((Integer) WritableUtils.readVInt(di));
    }

    @Override
    public int compareTo(Message o) {
        int res = getvDegree().compareTo(o.getvDegree());
        return res;
    }

    @Override
    public String toString() {
        return "Message{" + "vID=" + getvID() + ", vDegree=" + getvDegree() + '}';
    }

    /**
     * @return the vID
     */
    public Integer getvID() {
        return vID;
    }

    /**
     * @param vID the vID to set
     */
    public void setvID(Integer vID) {
        this.vID = vID;
    }

    /**
     * @return the vDegree
     */
    public Integer getvDegree() {
        return vDegree;
    }

    /**
     * @param vDegree the vDegree to set
     */
    public void setvDegree(Integer vDegree) {
        this.vDegree = vDegree;
    }

    
    

    

}
